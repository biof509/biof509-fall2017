
## Creating a web interface for data analysis scripts

analysis.py  contains data analysis code
site.py contains web application built with Flask framework


## How to run
pip install -r requirements.txt
python site.py

